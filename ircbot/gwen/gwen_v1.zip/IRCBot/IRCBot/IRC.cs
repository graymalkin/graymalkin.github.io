﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace IRCBot
{
    public class IRC
    {
        public delegate void MessageEventHandler(object sender, Events.MessageReceivedEventArgs e);
        public event MessageEventHandler MessageEvent;
        public delegate void ConnectedEventHandler(object sender, Events.ConnectionEventArgs e);
        public event ConnectedEventHandler ConnectedEvent;
        public struct Message
        {
            private static byte[] SPACE = System.Text.Encoding.ASCII.GetBytes(" ");
            private string msg, messagetarget, messagefrom;
            private byte[] messagecommand;

            /// <summary>
            /// Create a new Message instance
            /// </summary>
            /// <param name="m">Message to send</param>
            /// <param name="t">Target to send the message to</param>
            /// <param name="c">The command for the messgae (eg SAY)</param>
            public Message(string m, string t, byte[] c)
            {
                msg = m;
                messagetarget = t;
                messagecommand = c;
                messagefrom = "";
            }

            public Message(string m, string t, byte[] c, string f)
            {
                msg = m;
                messagetarget = t;
                messagecommand = c;
                messagefrom = f;
            }

            public string sender
            {
                get { return messagefrom; }
            }

            public string message
            {
                get { return msg; }
            }

            public string target
            {
                get { return messagetarget; }
            }

            public byte[] command
            {
                get { return messagecommand; }
            }

            public byte[] toByteArray()
            {
                byte[] toSend = new byte[command.Length + 1 + messagetarget.Length + 1 + msg.Length + 1];

                command.CopyTo(toSend, 0);

                if (messagetarget != "")
                {
                    SPACE.CopyTo(toSend, command.Length);
                    System.Text.Encoding.ASCII.GetBytes(messagetarget).CopyTo(toSend, command.Length + 1);

                    SPACE.CopyTo(toSend, command.Length + 1 + messagetarget.Length);
                    System.Text.Encoding.ASCII.GetBytes(msg).CopyTo(toSend, command.Length + 1 + messagetarget.Length + 1);
                }
                else
                {
                    SPACE.CopyTo(toSend, command.Length);
                    System.Text.Encoding.ASCII.GetBytes(msg).CopyTo(toSend, command.Length + 1);
                }

                return fixDeg(toSend);
            }
        }

        System.Net.Sockets.TcpClient tcpClient;
        System.Net.Sockets.NetworkStream tcpStream;

        private string chatnet, nickname, realname, netname;
        private int port;
        
        public IRC(string _chatNet, string _netname, string _nickname, string _realname, int _port)
        {
            tcpClient = new System.Net.Sockets.TcpClient(_chatNet, _port);
            tcpClient.NoDelay = true;
            tcpStream = tcpClient.GetStream();
            tcpClient.NoDelay = true;

            chatnet = _chatNet;
            port = _port;
            realname = _realname;
            nickname = _nickname;
            netname = _netname;
        }

        public void run()
        {
            while (tcpClient.Connected)
            {
                if (tcpClient.Available > 0)
                {
                    int totalBytes = tcpClient.Available;
                    byte[] data = new byte[tcpClient.Available];
                    for (int i = 0; i < totalBytes; i++)
                    {
                        byte[] b = new byte[] { (byte)tcpStream.ReadByte() };
                        b.CopyTo(data, i);
                    }

                    string received = System.Text.Encoding.ASCII.GetString(data);

                    foreach (string ln in received.Split("\n".ToCharArray()))
                    {
                        if (ln != "")
                            output("RECEIVED", ConsoleColor.Green, ln);
                    }

                    if (received.Contains("NOTICE AUTH :*** No Ident response"))
                    {
                        beginIrc();
                    }

                    Message m = parseMessage(received);
                    NewMessageEvent(m);
                }
                tcpStream.Flush();
            }
        }

        private Message parseMessage(string text)
        {
            string msg = "", target = "", command = "", from ="";

            if (text.StartsWith("PING", true, System.Globalization.CultureInfo.CurrentCulture))
            {
                command = "PING";
                target = "";
                msg = text.Split(':')[1];

                // Because this is a ping, we shall pong
                Message pong = new Message(msg, "", SERVER_COMMANDS.PONG);
                send(pong);
            }
            else
            {
                command = text.Split(' ')[1];
                if(command == "PRIVMSG")
                    from = text.Split(' ')[0].Split(':')[1].Split('!')[0]; 
                target = text.Split(' ')[2];
                for (int i = 3; i < text.Split(' ').Length; i++)
                {
                    msg = msg + " " + text.Split(' ')[i];
                }
            }

            return new Message(msg, target, System.Text.Encoding.ASCII.GetBytes(command), from);
        }

        private void beginIrc()
        {
            if (tcpClient.Connected == false)
                tcpClient.Connect(chatnet, port);

            while (tcpClient.Available > 0)
            { /* Wait for the server to finish introducing itself */ }

            Message nickMsg = new Message(nickname, "", SERVER_COMMANDS.NICK);
            Message userMessage = new Message(":" + realname, nickname + " " +netname + " "+ netname, SERVER_COMMANDS.USER);

            send(nickMsg);
            send(userMessage); 

            while (tcpClient.Available < 0) ;     // Wait for response
            Connected("Connected");
        }

        public void join(string channelName)
        {
            Message m = new Message("", channelName, SERVER_COMMANDS.JOIN);
            send(m);
        }

        public void part(string channelName)
        {
            Message m = new Message("", channelName, SERVER_COMMANDS.PART);
            send(m);
        }

        public void send(Message msg)
        {
            tcpStream.Flush();
            byte[] data = msg.toByteArray();
            byte[] newLine = System.Text.Encoding.ASCII.GetBytes("\r\n");
            string tosend = System.Text.Encoding.ASCII.GetString(data);

            //Console.WriteLine("[SENT]\t\t {0}", tosend);
            output("SENT", ConsoleColor.Red, tosend);

            tcpStream.Write(data, 0, data.Length);
            tcpStream.Write(newLine, 0, newLine.Length);
        }

        private void output(string type, ConsoleColor color, string msg)
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("[");
            Console.ForegroundColor = color;
            Console.Write(type);
            Console.ForegroundColor = ConsoleColor.White;
            string tmp = "";
            for (int i = 0; i < msg.Length; i++)
            {
                tmp += msg.ToCharArray()[i];
                if (i % 85 == 0 && i > 0)
                {
                    tmp += "\n\t\t ";
                }
            }
            
            if (type.Length < 5)
                Console.Write(" " + getTimeString() + "]\t {0}\n", tmp);
            else
                Console.Write(" " + getTimeString() + "]  {0}\n", tmp);
        }

        private string getTimeString()
        {
            string time = "";

            if (DateTime.Now.Hour < 10)
                time += "0";
            time += DateTime.Now.Hour + ":";

            if (DateTime.Now.Minute < 10)
                time += "0";
            time += DateTime.Now.Minute;

            return time;
        }

        public void send(byte[] data)
        {
            tcpStream.Write(data, 0, data.Length);
        }

        public static byte[] fixDeg(byte[] input)
        {
            int degCount = 0;
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] == 63)
                {
                    degCount++;
                }
            }

            byte[] utf8DegSym = { 0xC2, 0xB0 };
            byte[] output = new byte[input.Length + degCount];
            int locationInOut = 0;
            for (int j = 0; j < input.Length; j++)
            {
                if (input[j] == 63)
                {
                    output[locationInOut] = 0xC2;
                    locationInOut++;
                    output[locationInOut] = 0xB0;
                    locationInOut++;
                }
                else
                {
                    output[locationInOut] = input[j];
                    locationInOut++;
                }
            }
            
            return output;
        }

        public void NewMessageEvent(Message m)
        {
            if (MessageEvent == null)
                return;

            Events.MessageReceivedEventArgs args = new Events.MessageReceivedEventArgs(m);
            MessageEvent(this, args);
        }

        public void Connected(string m)
        {
            if (ConnectedEvent == null)
                return;

            Events.ConnectionEventArgs args = new Events.ConnectionEventArgs(m);
            ConnectedEvent(this, args);
        }
    }

    public class SERVER_COMMANDS
    {
        
        public static byte[] NICK = System.Text.Encoding.ASCII.GetBytes("NICK");
        public static byte[] USER = System.Text.Encoding.ASCII.GetBytes("USER");
        public static byte[] PING = System.Text.Encoding.ASCII.GetBytes("PING");
        public static byte[] PONG = System.Text.Encoding.ASCII.GetBytes("PONG");
        public static byte[] JOIN = System.Text.Encoding.ASCII.GetBytes("JOIN ");
        public static byte[] PART = System.Text.Encoding.ASCII.GetBytes("PART ");
        public static byte[] QUIT = System.Text.Encoding.ASCII.GetBytes("QUIT ");
        public static byte[] PRIVMSG = System.Text.Encoding.ASCII.GetBytes("PRIVMSG");
    }
}
