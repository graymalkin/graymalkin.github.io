﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRCBot.Events
{
    public class MessageReceivedEventArgs : EventArgs
    {
        public IRCBot.IRC.Message Message { get; private set; }

        public MessageReceivedEventArgs(IRCBot.IRC.Message m)
        {
            Message = m;
        }
    }

    public class ConnectionEventArgs : EventArgs
    {
        public string Message { get; private set; }

        public ConnectionEventArgs(string m)
        {
            Message = m;
        }
    }
}