﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Net;
using System.Xml.XPath;
using System.Xml.Linq;
using System.Web;

namespace IRCBot
{
    class Weather
    {
        private static string apiKey = "CGo4VVfV34Gx5NISJtVqCTVSAMFYF0wMgMNvx.oTjeX5KQvfFHGEmN90vU.3Uwp.I3U-";
        public string getWeather()
        {
            return getWeather("Canterbury");
        }

        public string getWeather(string locaiton)
        {
            if (locaiton == "")
                locaiton = "Canterbury";

            string resultString = "Weather for ";
            char degree = (char)176;

            output("PROCESSING", ConsoleColor.Yellow, resultString + " " + locaiton);
            locaiton = locaiton.Trim();

            try  
            {
                XNamespace xNamespace = "http://xml.weather.yahoo.com/ns/rss/1.0"; //replace this with namespace of prefix 'yweather'
                XDocument xDocument = XDocument.Load(@"http://weather.yahooapis.com/forecastrss?u=c&w=" + getWOEID(HttpUtility.UrlEncode(locaiton)));

                var result = from item in xDocument.Descendants(xNamespace + "location")
                             select item;

                foreach (XElement item in result)
                {
                    resultString += item.Attribute("city").Value + ", ";
                    if (item.Attribute("region").Value != "")
                        resultString += item.Attribute("region").Value + ", ";
                    resultString += item.Attribute("country").Value +  ": ";
                }


                result = from item in xDocument.Descendants(xNamespace + "condition")
                             select item;

                foreach (XElement item in result)
                {
                    resultString += item.Attribute("text").Value + ", ";
                    resultString += item.Attribute("temp").Value + degree + "C. ";
                }

                result = from item in xDocument.Descendants(xNamespace + "wind")
                         select item;

                foreach (XElement item in result)
                {
                    resultString += "Wind Speed " + item.Attribute("speed").Value + "km/h, with a ";
                    resultString += item.Attribute("chill").Value + degree + "C Chill. ";
                }

                result = from item in xDocument.Descendants(xNamespace + "atmosphere")
                         select item;

                foreach (XElement item in result)
                {
                    resultString += "Humidity " + item.Attribute("humidity").Value + "%, Visibility ";
                    resultString += item.Attribute("visibility").Value + "km.";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                
            }

            if (resultString != "Weather for ")
                return resultString;
            else
                return "Could not find " + locaiton;

        }

        public string getWOEID(string query)
        {
            string id = "";

            //XElement doc = XElement.Load("http://where.yahooapis.com/v1/places.q('" + query + "')?appid=" + apiKey);
            //doc = new 
            // id = doc.XPathSelectElement(@"woeid").Value;
            //XName woeidXName = "woeid";
            //id = doc.Element(woeidXName).Value;

            XNamespace xNamespace = "http://where.yahooapis.com/v1/schema.rng"; //replace this with namespace of prefix 'yweather'
            string url = "http://where.yahooapis.com/v1/places.q('" + query + "')?appid=" + apiKey;
            XDocument xDocument = XDocument.Load(url);
            var result = from item in xDocument.Descendants(xNamespace + @"woeid")
                         select item;

            foreach (XElement item in result)
            {
                id = item.Value;
            }

            return id;            
        }

        private void output(string type, ConsoleColor color, string msg)
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("[");
            Console.ForegroundColor = color;
            Console.Write(type);
            Console.ForegroundColor = ConsoleColor.White;
            string tmp = "";
            for (int i = 0; i < msg.Length; i++)
            {
                tmp += msg.ToCharArray()[i];
                if (i % 85 == 0 && i > 0)
                {
                    tmp += "\n\t\t ";
                }
            }
            if (type.Length < 5)
                Console.Write("]\t\t {0}\n", tmp);
            else
                Console.Write("]\t {0}\n", tmp);
        }
    }
}
