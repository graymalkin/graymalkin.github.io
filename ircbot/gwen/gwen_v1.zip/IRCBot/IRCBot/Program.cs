﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRCBot
{
    class Run
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.Main(args);
        }
    }
    class Program
    {
        IRC irc;
        Weather w;

        public void Main(string[] args)
        {
            irc = new IRC("irc.compsoc.kent.ac.uk", "KentIRC", "Gwen", "Simon Moore's C#.NET Bot", 6667);
            irc.ConnectedEvent += new IRC.ConnectedEventHandler(irc_ConnectedEvent);
            irc.MessageEvent += new IRC.MessageEventHandler(irc_MessageEvent);

            irc.run();
        }

        void irc_ConnectedEvent(object sender, Events.ConnectionEventArgs e)
        {
            // irc.join("#cs");
        }

        void irc_MessageEvent(object sender, Events.MessageReceivedEventArgs e)
        {
            if(e.Message.message.StartsWith(" :$weather"))
            {
                IRCBot.IRC.Message response;
                string[] cmd = e.Message.message.Split(' ');
                string msg = "", query = "";

                if (cmd.Length > 2)
                {
                    for (int i = 2; i < cmd.Length; i++)
                    {
                        query += cmd[i].Replace("\r\n", "") + " ";
                    }
                }
                w = new Weather();
                msg = w.getWeather(query);

                response = new IRC.Message(":" + msg, e.Message.target, e.Message.command);
                irc.send(response);
            }

            if(e.Message.message.StartsWith(" :$join"))
            {
                if (e.Message.sender != "graymalkin")
                    return;

                string[] cmd = e.Message.message.Split(' ');
                for(int i = 2; i < cmd.Length; i++)
                {
                    irc.join(cmd[i]);
                }
            }

            if (e.Message.message.StartsWith(" :$leave"))
            {
                if (e.Message.sender != "graymalkin")
                    return;

                string[] cmd = e.Message.message.Split(' ');
                for (int i = 2; i < cmd.Length; i++)
                {
                    irc.part(cmd[i].Trim());
                }
            }
        }
    }
}
